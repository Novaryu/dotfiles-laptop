local module = {}
local mappings = {}

local make_key = function(mode, lhs)
	-- check if multiple modes present, then concatenate
    if type(mode) == 'table' then
        mode = table.concat(mode, ",")
    end
    return mode .. ' ' .. lhs
end

module.set = function(mode, lhs, rhs, opts, doc_string)
	local mode_str = mode
	
	-- check if multiple modes present, then concatenate
	if type(mode) == 'table' then
		mode_str = table.concat(mode, ",")
	end
	
    mappings[make_key(mode, lhs)] = {
		mode = mode_str,
        lhs = lhs,
        rhs = rhs,
        doc_string = doc_string
    }

    opts.desc = doc_string
    vim.keymap.set(mode, lhs, rhs, opts)
end

module.get = function(mode, lhs)
    return mappings[make_key(mode, lhs)]
end

module.get_all = function()
    return mappings
end

return module
